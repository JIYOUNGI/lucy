package egovframework.example.sample.service;

import java.util.List;

public interface DeptService {
	//string list deptvo 다 리턴타입, 받는곳임
	public String InsertDept(DeptVO vo) throws Exception;
	public List<?> SelectDeptList(DeptVO vo) throws Exception;
	public DeptVO selectDeptDetail(int deptno) throws Exception;
	public int deleteDept (int deptno) throws Exception;
	public int updateDept(DeptVO vo) throws Exception;
	
}
